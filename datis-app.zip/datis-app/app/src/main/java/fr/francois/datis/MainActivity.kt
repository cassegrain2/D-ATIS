package fr.francois.datis

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import fr.francois.datis.data.AtisRepository
import fr.francois.datis.ui.AtisScreen
import fr.francois.datis.ui.DatisTheme
import fr.francois.datis.widget.AtisRefreshWorker

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        AtisRefreshWorker.schedule(this)
        val repo = AtisRepository(applicationContext)
        setContent { DatisTheme { AtisScreen(repo) } }
    }
}
