package fr.francois.datis.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

private val Context.dataStore by preferencesDataStore(name = "datis")

data class AirportState(
    val icao: String,
    val reports: List<AtisReport> = emptyList(),
    val fetchedAtMs: Long? = null,
    val error: String? = null,
)

/** Liste d'aéroports (le premier est celui du widget) + cache des derniers ATIS. */
class AtisRepository(context: Context) {
    private val store = context.applicationContext.dataStore

    val states: Flow<List<AirportState>> = store.data.map { prefs ->
        val cache = decode(prefs[CACHE])
        airports(prefs).map { cache[it] ?: AirportState(it) }
    }

    suspend fun addAirport(icao: String) {
        val code = icao.trim().uppercase()
        if (!code.matches(ICAO)) return
        store.edit { p ->
            val list = airports(p)
            if (code !in list) p[AIRPORTS] = (list + code).joinToString(",")
        }
    }

    suspend fun removeAirport(icao: String) {
        store.edit { p ->
            p[AIRPORTS] = (airports(p) - icao).joinToString(",")
            p[CACHE] = encode(decode(p[CACHE]) - icao)
        }
    }

    /** Place l'aéroport en tête de liste : c'est lui que le widget affiche. */
    suspend fun pinAirport(icao: String) {
        store.edit { p ->
            val list = airports(p)
            if (icao in list) p[AIRPORTS] = (listOf(icao) + (list - icao)).joinToString(",")
        }
    }

    suspend fun refreshAll() {
        val list = airports(store.data.first())
        list.forEachIndexed { i, icao ->
            if (i > 0) delay(500) // on reste poli avec l'API
            refresh(icao)
        }
    }

    suspend fun refresh(icao: String) {
        val now = System.currentTimeMillis()
        val result = runCatching { fetch(icao, now) }
        store.edit { p ->
            val cache = decode(p[CACHE]).toMutableMap()
            val old = cache[icao] ?: AirportState(icao)
            cache[icao] = result.fold(
                onSuccess = { fresh -> AirportState(icao, latestPerKind(old.reports + fresh, now), now, null) },
                onFailure = { e ->
                    old.copy(reports = latestPerKind(old.reports, now), error = e.message ?: "Erreur réseau")
                },
            )
            p[CACHE] = encode(cache)
        }
    }

    private suspend fun fetch(icao: String, now: Long): List<AtisReport> = withContext(Dispatchers.IO) {
        val url = URL("$API?text=$icao&labels=A9&timeframe=last-day&limit=100")
        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15_000
            conn.readTimeout = 20_000
            conn.setRequestProperty("Accept", "application/json")
            conn.setRequestProperty("User-Agent", "DATIS-Android/1.0 (usage personnel)")
            when (val code = conn.responseCode) {
                200 -> Unit
                429 -> throw IOException("Trop de requêtes vers Airframes, réessaie dans quelques minutes")
                else -> throw IOException("Airframes a répondu avec l'erreur HTTP $code")
            }
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val arr = JSONArray(body)
            (0 until arr.length()).flatMap { i ->
                AtisParser.parse(arr.getJSONObject(i).optString("text"), icao, now)
            }
        } finally {
            conn.disconnect()
        }
    }

    /** Garde le plus récent par type (ARR/DEP), ce qui élimine aussi les doublons. */
    private fun latestPerKind(list: List<AtisReport>, now: Long): List<AtisReport> =
        list.filter { now - it.issuedAtMs < MAX_AGE_MS }
            .groupBy { it.kind }
            .values.map { group -> group.maxBy { it.issuedAtMs } }
            .sortedBy { KIND_ORDER.indexOf(it.kind) }

    private fun airports(p: Preferences): List<String> =
        p[AIRPORTS]?.split(',')?.filter { it.isNotBlank() } ?: listOf(DEFAULT_AIRPORT)

    private fun encode(map: Map<String, AirportState>): String = JSONObject().apply {
        map.forEach { (icao, s) ->
            put(icao, JSONObject().apply {
                put("reports", JSONArray().apply { s.reports.forEach { put(it.toJson()) } })
                s.fetchedAtMs?.let { put("fetchedAt", it) }
                s.error?.let { put("error", it) }
            })
        }
    }.toString()

    private fun decode(json: String?): Map<String, AirportState> {
        if (json.isNullOrBlank()) return emptyMap()
        return runCatching {
            val o = JSONObject(json)
            o.keys().asSequence().associateWith { k ->
                val s = o.getJSONObject(k)
                val arr = s.optJSONArray("reports") ?: JSONArray()
                AirportState(
                    icao = k,
                    reports = List(arr.length()) { AtisReport.fromJson(arr.getJSONObject(it)) },
                    fetchedAtMs = if (s.has("fetchedAt")) s.getLong("fetchedAt") else null,
                    error = if (s.has("error")) s.getString("error") else null,
                )
            }
        }.getOrDefault(emptyMap())
    }

    companion object {
        private val AIRPORTS = stringPreferencesKey("airports")
        private val CACHE = stringPreferencesKey("cache")
        private val ICAO = Regex("[A-Z]{4}")
        private val KIND_ORDER = listOf("ARR", "DEP", "")
        private const val API = "https://api.airframes.io/v1/messages"
        private const val DEFAULT_AIRPORT = "LFPO"
        private const val MAX_AGE_MS = 24 * 60 * 60_000L
    }
}
