package fr.francois.datis.widget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.ColorFilter
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.action.ActionParameters
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.appWidgetBackground
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.updateAll
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.size
import androidx.glance.layout.width
import androidx.glance.text.FontFamily
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import fr.francois.datis.MainActivity
import fr.francois.datis.R
import fr.francois.datis.data.AirportState
import fr.francois.datis.data.AtisRepository
import fr.francois.datis.data.ageLabel

class AtisWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val repo = AtisRepository(context)
        provideContent {
            val states by repo.states.collectAsState(initial = null)
            GlanceTheme { WidgetContent(states) }
        }
    }
}

@Composable
private fun WidgetContent(states: List<AirportState>?) {
    val state = states?.firstOrNull()
    val report = state?.reports?.firstOrNull()
    val now = System.currentTimeMillis()
    val onSurface = GlanceTheme.colors.onSurface
    val muted = GlanceTheme.colors.onSurfaceVariant

    Column(
        modifier = GlanceModifier
            .fillMaxSize()
            .appWidgetBackground()
            .background(GlanceTheme.colors.widgetBackground)
            .cornerRadius(20.dp)
            .padding(14.dp)
            .clickable(actionStartActivity<MainActivity>()),
    ) {
        Row(modifier = GlanceModifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            if (report != null) {
                Text(
                    text = report.letter,
                    style = TextStyle(color = GlanceTheme.colors.primary, fontSize = 34.sp, fontWeight = FontWeight.Bold),
                )
                Spacer(GlanceModifier.width(10.dp))
            }
            Column(modifier = GlanceModifier.defaultWeight()) {
                Text(
                    text = listOfNotNull(state?.icao ?: "D-ATIS", report?.kind?.ifEmpty { null }).joinToString(" "),
                    style = TextStyle(color = onSurface, fontSize = 15.sp, fontWeight = FontWeight.Bold),
                )
                if (report != null) {
                    val stale = now - report.issuedAtMs > 60 * 60_000L
                    Text(
                        text = "${report.hhmm}Z, ${ageLabel(now - report.issuedAtMs)}",
                        style = TextStyle(color = if (stale) GlanceTheme.colors.error else muted, fontSize = 12.sp),
                    )
                }
            }
            Image(
                provider = ImageProvider(R.drawable.ic_refresh),
                contentDescription = "Rafraîchir",
                colorFilter = ColorFilter.tint(muted),
                modifier = GlanceModifier.size(26.dp).clickable(actionRunCallback<RefreshAction>()),
            )
        }

        Spacer(GlanceModifier.height(8.dp))

        when {
            states == null -> Text("Chargement…", style = TextStyle(color = muted, fontSize = 13.sp))
            state == null -> Text(
                "Ajoute un aéroport dans l'application",
                style = TextStyle(color = muted, fontSize = 13.sp),
            )
            report == null -> Text(
                state.error ?: "Aucun D-ATIS reçu ces dernières 24 h",
                style = TextStyle(color = muted, fontSize = 13.sp),
            )
            else -> {
                val key = listOfNotNull(report.qnh?.let { "QNH $it" }, report.runways).joinToString("   ")
                if (key.isNotEmpty()) {
                    Text(key, style = TextStyle(color = onSurface, fontSize = 13.sp, fontWeight = FontWeight.Medium), maxLines = 2)
                    Spacer(GlanceModifier.height(6.dp))
                }
                Text(
                    text = report.lines.joinToString("\n"),
                    style = TextStyle(color = onSurface, fontSize = 11.sp, fontFamily = FontFamily.Monospace),
                )
            }
        }
    }
}

class RefreshAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        AtisRepository(context).refreshAll()
        AtisWidget().updateAll(context)
    }
}

class AtisWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = AtisWidget()

    override fun onEnabled(context: Context) {
        super.onEnabled(context)
        AtisRefreshWorker.schedule(context)
    }
}
