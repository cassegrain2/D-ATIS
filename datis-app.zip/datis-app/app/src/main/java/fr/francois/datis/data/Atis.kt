package fr.francois.datis.data

import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.ZoneOffset
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

/** Un D-ATIS décodé. [kind] vaut "ARR", "DEP" ou "" si non précisé. */
data class AtisReport(
    val icao: String,
    val kind: String,
    val letter: String,
    val hhmm: String,
    val issuedAtMs: Long,
    val lines: List<String>,
) {
    val qnh: String?
        get() = lines.firstNotNullOfOrNull { QNH.find(it)?.groupValues?.get(1) }

    val runways: String?
        get() = lines.firstOrNull { l ->
            l.contains("RWY") && !l.contains("CLSD") &&
                (l.startsWith("ARR") || l.startsWith("DEP") || l.startsWith("RWY"))
        }

    val approach: String?
        get() = lines.firstOrNull { it.startsWith("EXPECT") || it.startsWith("APCH") }

    fun toJson(): JSONObject = JSONObject().apply {
        put("icao", icao); put("kind", kind); put("letter", letter)
        put("hhmm", hhmm); put("issuedAt", issuedAtMs); put("lines", JSONArray(lines))
    }

    companion object {
        private val QNH = Regex("""QNH\s*:?\s*(\d{3,4})""")

        fun fromJson(o: JSONObject): AtisReport {
            val arr = o.getJSONArray("lines")
            return AtisReport(
                icao = o.getString("icao"),
                kind = o.optString("kind"),
                letter = o.getString("letter"),
                hhmm = o.getString("hhmm"),
                issuedAtMs = o.getLong("issuedAt"),
                lines = List(arr.length()) { arr.getString(it) },
            )
        }
    }
}

/**
 * Décode le texte des messages ACARS (label A9).
 * Format européen : "/ORYATYA.TI2/LFPO ARR ATIS F\n0727Z\n..."
 * Format SITA/australien : "ATIS YMML P 250329 APCH: ... -----END OF MESSAGE-----"
 * Les messages tronqués (sans en-tête) sont ignorés.
 */
object AtisParser {
    private val TI2 = Regex("""^/[A-Z0-9]+\.TI2/([A-Z]{4})\s+(?:(ARR|DEP)\s+)?ATIS\s+([A-Z])\s+(\d{4})Z""")
    private val SITA = Regex("""^ATIS\s+([A-Z]{4})\s+([A-Z])\s+\d{2}(\d{4})\b""")
    private val TRAILING_CRC = Regex("""(ATIS\s+[A-Z])[0-9A-F]{4}\s*$""")
    private val KEYWORD_SPLIT =
        Regex("""\s+(?=(?:APCH|RWY|WND|WX|TMP|QNH|CLD|VIS|SIGWX|OPR INFO|HAZ WX):)""")
    private val NEWLINE = Regex("""\r?\n""")
    private val SPACES = Regex(""" {2,}""")
    private const val END = "-----END OF MESSAGE-----"

    fun parse(text: String, icao: String, nowMs: Long = System.currentTimeMillis()): List<AtisReport> {
        val t = text.trim()

        TI2.find(t)?.let { m ->
            val (code, kind, letter, hhmm) = m.destructured
            if (code != icao) return emptyList()
            val issued = issuedAt(hhmm, nowMs) ?: return emptyList()
            val lines = t.substring(m.range.last + 1)
                .split(NEWLINE).map(::clean).filter { it.isNotEmpty() }.toMutableList()
            if (lines.isNotEmpty()) lines[lines.lastIndex] = lines.last().replace(TRAILING_CRC, "\$1")
            return listOf(AtisReport(code, kind, letter, hhmm, issued, lines))
        }

        return t.split(END).mapNotNull { chunk ->
            val c = chunk.trim()
            val m = SITA.find(c) ?: return@mapNotNull null
            val (code, letter, hhmm) = m.destructured
            if (code != icao) return@mapNotNull null
            val issued = issuedAt(hhmm, nowMs) ?: return@mapNotNull null
            val lines = c.substring(m.range.last + 1).replace(NEWLINE, " ")
                .split(KEYWORD_SPLIT).map(::clean).filter { it.isNotEmpty() }
            AtisReport(code, "", letter, hhmm, issued, lines)
        }
    }

    /**
     * L'heure de l'ATIS est lue dans le texte, car l'horodatage de l'API
     * dépend de l'horloge de la station réceptrice et peut être faux.
     */
    fun issuedAt(hhmm: String, nowMs: Long): Long? {
        val h = hhmm.substring(0, 2).toIntOrNull() ?: return null
        val m = hhmm.substring(2, 4).toIntOrNull() ?: return null
        if (h > 23 || m > 59) return null
        var t = ZonedDateTime.ofInstant(Instant.ofEpochMilli(nowMs), ZoneOffset.UTC)
            .withHour(h).withMinute(m).withSecond(0).withNano(0)
        if (t.toInstant().toEpochMilli() > nowMs + 15 * 60_000L) t = t.minusDays(1)
        return t.toInstant().toEpochMilli()
    }

    private fun clean(s: String) = s.replace('\t', ' ').trim().replace(SPACES, " ")
}

private val ZULU = DateTimeFormatter.ofPattern("HH:mm'Z'").withZone(ZoneOffset.UTC)

fun zulu(ms: Long): String = ZULU.format(Instant.ofEpochMilli(ms))

fun ageLabel(ms: Long): String {
    val min = (ms / 60_000).coerceAtLeast(0)
    return when {
        min < 1 -> "à l'instant"
        min < 60 -> "il y a $min min"
        else -> "il y a ${min / 60} h ${"%02d".format(min % 60)}"
    }
}
