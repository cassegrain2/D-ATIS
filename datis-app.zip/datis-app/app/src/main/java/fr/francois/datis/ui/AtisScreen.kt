package fr.francois.datis.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.glance.appwidget.updateAll
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import fr.francois.datis.data.AirportState
import fr.francois.datis.data.AtisReport
import fr.francois.datis.data.AtisRepository
import fr.francois.datis.data.ageLabel
import fr.francois.datis.data.zulu
import fr.francois.datis.widget.AtisWidget
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AtisScreen(repo: AtisRepository) {
    val states by repo.states.collectAsStateWithLifecycle(initialValue = emptyList())
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var refreshing by remember { mutableStateOf(false) }
    var showAdd by remember { mutableStateOf(false) }
    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            delay(30_000)
            value = System.currentTimeMillis()
        }
    }

    val refresh: () -> Unit = {
        if (!refreshing) scope.launch {
            refreshing = true
            try {
                repo.refreshAll()
                AtisWidget().updateAll(context)
            } finally {
                refreshing = false
            }
        }
    }
    LaunchedEffect(Unit) { refresh() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("D-ATIS") },
                actions = {
                    IconButton(onClick = refresh) { Icon(Icons.Default.Refresh, contentDescription = "Rafraîchir") }
                },
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAdd = true }) {
                Icon(Icons.Default.Add, contentDescription = "Ajouter un aéroport")
            }
        },
    ) { padding ->
        PullToRefreshBox(
            isRefreshing = refreshing,
            onRefresh = refresh,
            modifier = Modifier.fillMaxSize().padding(padding),
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                itemsIndexed(states, key = { _, s -> s.icao }) { index, s ->
                    AirportCard(
                        state = s,
                        pinned = index == 0,
                        now = now,
                        onPin = { scope.launch { repo.pinAirport(s.icao); AtisWidget().updateAll(context) } },
                        onDelete = { scope.launch { repo.removeAirport(s.icao); AtisWidget().updateAll(context) } },
                    )
                }
                item {
                    Text(
                        "Source : Airframes.io, D-ATIS relayés par ACARS. Données non officielles, " +
                            "pas pour un usage opérationnel. L'étoile choisit l'aéroport du widget.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 4.dp),
                    )
                }
            }
        }
    }

    if (showAdd) {
        AddAirportDialog(
            onDismiss = { showAdd = false },
            onAdd = { code ->
                showAdd = false
                scope.launch {
                    repo.addAirport(code)
                    repo.refresh(code)
                    AtisWidget().updateAll(context)
                }
            },
        )
    }
}

@Composable
private fun AirportCard(
    state: AirportState,
    pinned: Boolean,
    now: Long,
    onPin: () -> Unit,
    onDelete: () -> Unit,
) {
    ElevatedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    state.icao,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = onPin) {
                    Icon(
                        Icons.Default.Star,
                        contentDescription = if (pinned) "Affiché dans le widget" else "Afficher dans le widget",
                        tint = if (pinned) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                    )
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Supprimer ${state.icao}")
                }
            }

            if (state.reports.isEmpty()) {
                Text(
                    if (state.fetchedAtMs == null && state.error == null) "Chargement…"
                    else "Aucun D-ATIS reçu ces dernières 24 h. Un avion doit l'avoir demandé par ACARS.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            state.reports.forEach { report ->
                Spacer(Modifier.height(8.dp))
                ReportBlock(report, now)
            }

            state.error?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            }
            state.fetchedAtMs?.let {
                Spacer(Modifier.height(8.dp))
                Text(
                    "Vérifié à ${zulu(it)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun ReportBlock(report: AtisReport, now: Long) {
    val age = now - report.issuedAtMs
    val stale = age > 60 * 60_000L

    Row(verticalAlignment = Alignment.CenterVertically) {
        Surface(
            color = MaterialTheme.colorScheme.primaryContainer,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.size(64.dp),
        ) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    report.letter,
                    style = MaterialTheme.typography.displaySmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            }
        }
        Spacer(Modifier.width(14.dp))
        Column {
            Text(
                "${report.kind.ifEmpty { "ATIS" }} ${report.hhmm}Z",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
            )
            Text(
                ageLabel(age),
                style = MaterialTheme.typography.bodyMedium,
                color = if (stale) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
            )
            report.qnh?.let {
                Text("QNH $it", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
            }
        }
    }

    val highlights = listOfNotNull(report.approach, report.runways)
    if (highlights.isNotEmpty()) {
        Spacer(Modifier.height(10.dp))
        highlights.forEach {
            Text(it, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
        }
    }

    Spacer(Modifier.height(10.dp))
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Text(
            report.lines.joinToString("\n"),
            fontFamily = FontFamily.Monospace,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(12.dp),
        )
    }
}

@Composable
private fun AddAirportDialog(onDismiss: () -> Unit, onAdd: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    val valid = text.length == 4

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ajouter un aéroport") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { v -> text = v.uppercase().filter { it in 'A'..'Z' }.take(4) },
                label = { Text("Code OACI") },
                placeholder = { Text("LFPG") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Characters,
                    imeAction = ImeAction.Done,
                ),
                keyboardActions = KeyboardActions(onDone = { if (valid) onAdd(text) }),
            )
        },
        confirmButton = { TextButton(onClick = { onAdd(text) }, enabled = valid) { Text("Ajouter") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}
