# D-ATIS

Appli Android + widget qui affiche les derniers D-ATIS relayés par ACARS,
via l'API publique d'Airframes.io (`/v1/messages`, label A9).

- Liste d'aéroports modifiable (LFPO par défaut), l'étoile choisit celui du widget.
- Rafraîchissement automatique toutes les 30 min, manuel dans l'appli et sur le widget.
- L'heure affichée est celle écrite dans l'ATIS (l'horodatage de l'API n'est pas fiable).
- Données non officielles, pas pour un usage opérationnel.

## Compiler

**Sans ordinateur (GitHub Actions)** : pousse ce dossier dans un dépôt GitHub.
Le workflow `.github/workflows/build.yml` compile l'APK à chaque push.
Onglet *Actions* > dernier build > *Artifacts* > `datis-apk`.

**Avec Android Studio** : *File > Open* sur ce dossier, puis *Run*.
